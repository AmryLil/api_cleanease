package p

import (
	"dep"
)

type algo struct {
	indrt func(dep.Interface)
}
